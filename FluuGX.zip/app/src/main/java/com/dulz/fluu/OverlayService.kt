package com.dulz.fluu

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

/**
 * Panel melayang native.
 *
 *  - Gelembung yang bisa digeser dan menempel ke tepi layar.
 *  - Panel dua sisi (info jaringan, suhu, layar, aksi cepat, 8 slot aplikasi).
 *  - Aplikasi dibuka melayang: jendela freeform asli bila didukung,
 *    atau jendela web (WhatsApp Web dan sejenisnya) sebagai cadangan.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var instance: OverlayService? = null

        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    }

    private class AppItem(val id: Long, val name: String, val pkg: String)

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())

    private var pal = defaultPal()
    private var open = false
    private var edgeRight = true
    private var sc = 1f

    private var tvPing: TextView? = null
    private var tvNet: TextView? = null
    private var tvTemp: TextView? = null
    private var tvHz: TextView? = null
    private var tvInfo: TextView? = null
    private var tvTorch: TextView? = null
    private var pingMs = -1
    private var ticks = 0

    private var webBox: LinearLayout? = null
    private var webLp: WindowManager.LayoutParams? = null
    private var webView: WebView? = null
    private var pickerBox: View? = null
    private var pickerLp: WindowManager.LayoutParams? = null

    private val tick = object : Runnable {
        override fun run() {
            if (ticks % 5 == 0) measurePing()
            ticks++
            updateStats()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = getSharedPreferences("dulz", MODE_PRIVATE)
        pal = loadPal()
        edgeRight = prefs.getBoolean("edgeR", true)
        startAsForeground()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = FrameLayout(this)

        val m = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("fx", m.widthPixels - dp(28))
            y = prefs.getInt("fy", (m.heightPixels * 0.34f).toInt())
        }
        applyFlags(false)
        wm.addView(root, lp)
        setOpen(false)
        refreshHud()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(watchTick)
        closeAllCtl(false)
        shellPool.shutdown()
        closeWeb()
        closePicker()
        hideHud()
        try {
            wm.removeView(root)
        } catch (e: Exception) {
            // sudah dilepas
        }
        instance = null
        super.onDestroy()
    }

    /** Dipanggil saat tema, daftar aplikasi, atau mode game berubah. */
    fun refresh() {
        ui.post {
            pal = loadPal()
            applyFlags(true)
            setOpen(open, false)
        }
    }

    // ---------------------------------------------------------------- Foreground

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("panel", "Panel melayang", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Fluu GX")
            .setContentText("Panel melayang aktif")
            .setSmallIcon(R.drawable.ic_gauge)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- Data

    private fun defaultPal() =
        Pal(0xFF3D4CF5.toInt(), 0xFF5663F8.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt())

    private fun loadPal(): Pal = try {
        val j = JSONObject(prefs.getString("theme", "") ?: "")
        Pal(
            Color.parseColor(j.getString("bg")),
            Color.parseColor(j.getString("surface")),
            Color.parseColor(j.getString("text")),
            Color.parseColor(j.getString("accent"))
        )
    } catch (e: Exception) {
        defaultPal()
    }

    private fun loadApps(): MutableList<AppItem> = try {
        val a = JSONArray(prefs.getString("apps", "[]") ?: "[]")
        val out = mutableListOf<AppItem>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(AppItem(o.optLong("id", i.toLong()), o.getString("name"), o.getString("pkg")))
        }
        out
    } catch (e: Exception) {
        mutableListOf()
    }

    private fun saveApps(list: List<AppItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("pkg", it.pkg)) }
        prefs.edit().putString("apps", a.toString()).apply()
        refresh()
        MainActivity.current?.syncFromNative()
    }

    private fun applyFlags(update: Boolean) {
        val keep = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        lp.flags = if (prefs.getBoolean("game", false)) lp.flags or keep else lp.flags and keep.inv()
        if (update) try {
            wm.updateViewLayout(root, lp)
        } catch (e: Exception) {
            // jendela belum terpasang
        }
    }

    // ---------------------------------------------------------------- Pembantu tampilan

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun withA(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r.toFloat()
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** Teks dengan ukuran piksel. */
    private fun txt(s: String, px: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
        includeFontPadding = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** Teks dengan ukuran sp. */
    private fun label(s: String, sp: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(s: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = s
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) pal.onAccent else pal.text)
        background = round(if (filled) pal.accent else withA(pal.text, 0x14), dp(12))
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- Bentuk panel

    /** Latar panel berbentuk bahu, dua sisi dengan garis pemisah di tengah. */
    private class PanelShape(
        private val fill: Int,
        private val line: Int,
        private val stroke: Float
    ) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun draw(canvas: Canvas) {
            val kx = bounds.width() / 1080f
            val ky = bounds.height() / 683f
            val pts = floatArrayOf(
                18f, 683f, 18f, 410f, 68f, 170f, 140f, 55f, 280f, 24f, 340f, 0f,
                740f, 0f, 800f, 24f, 940f, 55f, 1008f, 170f, 1060f, 410f, 1060f, 683f
            )
            val path = Path()
            var i = 0
            while (i < pts.size) {
                val x = pts[i] * kx
                val y = pts[i + 1] * ky
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                i += 2
            }
            path.close()

            paint.pathEffect = CornerPathEffect(26f * kx)
            paint.style = Paint.Style.FILL
            paint.color = fill
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = stroke
            paint.color = line
            canvas.drawPath(path, paint)

            paint.pathEffect = null
            canvas.drawLine(540f * kx, 0f, 540f * kx, bounds.height().toFloat(), paint)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}

        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    // ---------------------------------------------------------------- Gelembung dan panel

    /**
     * Tombol berupa tab tipis di tepi layar (seperti sidebar game).
     * Geser untuk memindah, lepas dan tab menempel ke tepi terdekat. Ketuk untuk membuka panel.
     */
    private fun buildBubble(): View {
        val touchW = dp(28)
        val tabW = dp(10)
        val tabH = dp(92)
        val v = FrameLayout(this).apply { layoutParams = FrameLayout.LayoutParams(touchW, tabH) }
        val r = dp(10).toFloat()
        val tab = View(this)
        tab.background = GradientDrawable().apply {
            setColor(Color.argb(0xC0, 0xF2, 0xF2, 0xF4))
            cornerRadii = if (edgeRight) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            setStroke(1, Color.argb(0x33, 0, 0, 0))
        }
        v.addView(
            tab,
            FrameLayout.LayoutParams(tabW, ViewGroup.LayoutParams.MATCH_PARENT, if (edgeRight) Gravity.END else Gravity.START)
        )
        drag(v, lp, root, true) { setOpen(true) }
        return v
    }

    private fun buildPanel(): View {
        val m = resources.displayMetrics
        val w = minOf(m.widthPixels - dp(16), dp(560))
        sc = w / 1080f
        val h = (683 * sc).toInt()
        val labelPx = maxOf(dp(9).toFloat(), 24 * sc)
        val bigPx = maxOf(dp(14).toFloat(), 52 * sc)
        val actPx = maxOf(dp(12).toFloat(), 38 * sc)
        val pad = maxOf(dp(6), (14 * sc).toInt())
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val card = FrameLayout(this)
        card.background = PanelShape(withA(pal.surface, 0xF2), withA(pal.text, 0x55), maxOf(1f, 3f * sc))
        card.layoutParams = FrameLayout.LayoutParams(w, h)

        fun put(v: View, x: Int, y: Int, tw: Int, th: Int) {
            val p = FrameLayout.LayoutParams((tw * sc).toInt(), (th * sc).toInt())
            p.leftMargin = (x * sc).toInt()
            p.topMargin = (y * sc).toInt()
            card.addView(v, p)
        }

        fun bg(fill: Int, stroke: Int): GradientDrawable {
            val d = round(fill, (26 * sc).toInt())
            d.setStroke(maxOf(1, (2.5f * sc).toInt()), stroke)
            return d
        }

        fun info(x: Int, y: Int, tw: Int, th: Int, title: String, onClick: (() -> Unit)?): Pair<TextView, TextView> {
            val tile = FrameLayout(this)
            tile.background = bg(withA(pal.accent, 0x30), pal.accent)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(pad, pad, pad, pad)
            col.addView(txt(title, labelPx, withA(pal.text, 0xB0), true))
            col.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
            val value = txt("--", bigPx, pal.text, true)
            val sub = txt("", labelPx, withA(pal.text, 0x99), false)
            col.addView(value)
            col.addView(sub)
            tile.addView(col, FrameLayout.LayoutParams(match, match))
            if (onClick != null) tile.setOnClickListener { onClick() }
            put(tile, x, y, tw, th)
            return Pair(value, sub)
        }

        fun action(x: Int, y: Int, tw: Int, th: Int, text: String, size: Float = actPx, onClick: () -> Unit) {
            val tile = FrameLayout(this)
            tile.background = bg(pal.accent, withA(pal.text, 0x55))
            val t = txt(text, size, pal.onAccent, true)
            t.gravity = Gravity.CENTER
            t.setPadding(pad, 0, pad, 0)
            tile.addView(t, FrameLayout.LayoutParams(match, match))
            tile.setOnClickListener { onClick() }
            put(tile, x, y, tw, th)
        }

        // Sisi kiri
        val ping = info(105, 130, 200, 200, "JARINGAN") { measurePing() }
        tvPing = ping.first
        tvNet = ping.second

        val temp = info(320, 130, 200, 200, "PANAS", null)
        tvTemp = temp.first
        temp.second.text = "Suhu baterai"

        val torch = FrameLayout(this)
        torch.background = bg(withA(pal.accent, 0x30), pal.accent)
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.gravity = Gravity.CENTER
        val tl = txt("SENTER", labelPx, withA(pal.text, 0xB0), true)
        tl.gravity = Gravity.CENTER
        tc.addView(tl)
        val ts = txt(if (Sys.torch(this)) "NYALA" else "MATI", labelPx, pal.text, true)
        ts.gravity = Gravity.CENTER
        tc.addView(ts)
        tvTorch = ts
        torch.addView(tc, FrameLayout.LayoutParams(match, match))
        torch.setOnClickListener { toggleTorch() }
        put(torch, 45, 345, 105, 200)

        val screen = info(163, 345, 357, 200, "LAYAR", null)
        tvHz = screen.first
        tvInfo = screen.second

        action(30, 568, 240, 102, "SEMUA APP", actPx * 0.8f) { showPicker(true) }
        action(280, 568, 240, 102, "ALAT", actPx * 0.8f) { showTools() }

        // Sisi kanan
        action(555, 187, 432, 109, "BERSIHKAN") { cleanNow() }
        val game = prefs.getBoolean("game", false)
        action(555, 312, 475, 108, if (game) "MODE GAME AKTIF" else "AKTIFKAN MODE GAME") { toggleGame() }

        val apps = loadApps()
        val xs = intArrayOf(555, 681, 807, 931)
        val ws = intArrayOf(110, 110, 111, 110)
        val ys = intArrayOf(435, 559)
        for (i in 0 until 8) {
            val tile = FrameLayout(this)
            tile.background = bg(withA(pal.accent, 0x30), withA(pal.accent, 0xAA))
            val item = apps.getOrNull(i)
            val icon = (64 * sc).toInt()
            if (item != null) {
                val ico: View = try {
                    ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(item.pkg)) }
                } catch (e: Exception) {
                    txt(item.name.take(1).uppercase(), actPx, pal.accent, true).apply { gravity = Gravity.CENTER }
                }
                tile.addView(ico, FrameLayout.LayoutParams(icon, icon, Gravity.CENTER))
                tile.setOnClickListener { launchApp(item.name, item.pkg) }
                tile.setOnLongClickListener { removeApp(item.pkg); true }
            } else {
                val plus = txt("+", actPx, withA(pal.text, 0x66), true)
                plus.gravity = Gravity.CENTER
                tile.addView(plus, FrameLayout.LayoutParams(match, match))
                tile.setOnClickListener { showPicker(false) }
            }
            put(tile, xs[i % 4], ys[i / 4], ws[i % 4], 110)
        }

        // Kepala (area geser) dan tombol tutup
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER
        head.addView(txt("Fluu GX", maxOf(dp(13).toFloat(), 40 * sc), pal.text, true))
        val close = ImageView(this)
        close.setImageResource(R.drawable.ic_close)
        close.setColorFilter(withA(pal.text, 0xB0))
        val cs = maxOf(dp(30), (56 * sc).toInt())
        close.setPadding(cs / 5, cs / 5, cs / 5, cs / 5)
        close.setOnClickListener { setOpen(false) }
        head.addView(close, LinearLayout.LayoutParams(cs, cs))
        drag(head, lp, root, false) {}
        put(head, 330, 6, 420, 100)

        return card
    }

    private fun setOpen(o: Boolean, animate: Boolean = true) {
        open = o
        ui.removeCallbacks(tick)
        root.removeAllViews()
        if (o) {
            val p = buildPanel()
            root.addView(p)
            if (animate) {
                p.alpha = 0f
                p.scaleX = .6f
                p.scaleY = .6f
                p.pivotX = 0f
                p.pivotY = 0f
                p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
            ticks = 0
            ui.post(tick)
            root.post { clampUpdate(lp, root) }
        } else {
            val b = buildBubble()
            root.addView(b)
            if (animate) {
                b.translationX = if (edgeRight) dp(28).toFloat() else -dp(28).toFloat()
                b.animate().translationX(0f).setDuration(260)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
            root.post { snapEdge() }
        }
    }

    // ---------------------------------------------------------------- Geser dan tempel

    private fun drag(v: View, p: WindowManager.LayoutParams, target: View, snap: Boolean, onTap: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && abs(dx) + abs(dy) > slop) moved = true
                    if (moved) {
                        p.x = (ox + dx).toInt()
                        p.y = (oy + dy).toInt()
                        clampUpdate(p, target)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        if (snap) snapEdge() else if (p === lp) savePos() else if (p === hudLp) saveHudPos()
                    } else onTap()
                }
            }
            true
        }
    }

    private fun clampUpdate(p: WindowManager.LayoutParams, v: View) {
        val m = resources.displayMetrics
        val w = if (v.width > 0) v.width else dp(54)
        val h = if (v.height > 0) v.height else dp(54)
        p.x = p.x.coerceIn(0, maxOf(0, m.widthPixels - w))
        p.y = p.y.coerceIn(0, maxOf(0, m.heightPixels - h))
        try {
            wm.updateViewLayout(v, p)
        } catch (e: Exception) {
            // jendela sudah dilepas
        }
    }

    private fun snapEdge() {
        val m = resources.displayMetrics
        val w = if (root.width > 0) root.width else dp(28)
        val right = lp.x + w / 2 >= m.widthPixels / 2
        if (!open && right != edgeRight) {
            edgeRight = right
            prefs.edit().putBoolean("edgeR", right).apply()
            root.removeAllViews()
            root.addView(buildBubble())
        }
        val target = if (right) m.widthPixels - w else 0
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try {
                    wm.updateViewLayout(root, lp)
                } catch (e: Exception) {
                    // jendela sudah dilepas
                }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) = savePos()
            })
            start()
        }
    }

    private fun savePos() {
        prefs.edit().putInt("fx", lp.x).putInt("fy", lp.y).apply()
    }

    // ---------------------------------------------------------------- Aksi

    private fun toggleGame() {
        val v = !prefs.getBoolean("game", false)
        prefs.edit().putBoolean("game", v).apply()
        toast(if (v) "Mode Game aktif. Layar tetap menyala" else "Mode Game dimatikan")
        refresh()
    }

    private fun toggleTorch() {
        val before = Sys.torch(this)
        val after = Sys.setTorch(this, !before)
        if (after == before) toast("Senter tidak tersedia di perangkat ini")
        updateStats()
    }

    private fun askWriteSettings() {
        toast("Izinkan Ubah pengaturan sistem untuk Fluu GX dulu")
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // layar pengaturan tidak tersedia
        }
    }

    private fun cleanNow() {
        toast("Membersihkan")
        Thread {
            val mb = Sys.clean(this)
            ui.post {
                toast(if (mb > 0.05) "Dibersihkan %.1f MB".format(mb) else "Tidak ada yang perlu dibersihkan")
            }
        }.start()
    }

    private fun removeApp(pkg: String) {
        val list = loadApps()
        val keep = list.filter { it.pkg != pkg }
        if (keep.size != list.size) {
            saveApps(keep)
            toast("Aplikasi dihapus dari panel")
        }
    }

    /** Membuka aplikasi sesuai mode: melayang (Shizuku, freeform, atau web) atau layar penuh. */
    private fun launchApp(name: String, pkg: String) {
        if (prefs.getString("mode", "float") != "float") {
            openFull(pkg)
            return
        }
        if (Sys.shizukuState() == "ready" && Shop.has(this, "float")) {
            Thread {
                val ok = Sys.openFloatingShizuku(this, pkg)
                var id = -1
                if (ok) {
                    var i = 0
                    while (i < 10 && id < 0) {
                        Thread.sleep(250)
                        id = Sys.findTaskId(pkg)
                        i++
                    }
                }
                val b: Rect? = if (id >= 0) floatBounds() else null
                if (b != null) Sys.resizeTask(id, b)
                ui.post {
                    if (!ok) {
                        launchFloatNormal(name, pkg)
                    } else {
                        setOpen(false)
                        if (b != null) showCtl(pkg, name, id, b)
                        else toast("Jendela terbuka, tapi kontrol belum tersedia di HP ini")
                    }
                }
            }.start()
            return
        }
        launchFloatNormal(name, pkg)
    }

    private fun openFull(pkg: String) {
        if (!Sys.open(this, pkg)) toast("Aplikasi tidak ditemukan")
        else setOpen(false)
    }

    private fun launchFloatNormal(name: String, pkg: String) {
        val m = resources.displayMetrics
        if (Sys.freeformOn(this)) {
            val f = when (prefs.getString("fsize", "m")) {
                "s" -> 0.45f
                "l" -> 0.8f
                else -> 0.6f
            }
            val w = (m.widthPixels * f).toInt()
            val h = (m.heightPixels * (f + 0.02f)).toInt()
            val l = (m.widthPixels - w) / 2
            val t = (m.heightPixels - h) / 4
            if (Sys.openFloatingBounds(this, pkg, Rect(l, t, l + w, t + h))) {
                setOpen(false)
                return
            }
        }
        val web = Sys.web(pkg)
        if (web != null) {
            showWeb(name, web)
            setOpen(false)
            return
        }
        toast("Jendela melayang belum aktif untuk aplikasi ini, dibuka layar penuh")
        openFull(pkg)
    }

    // ---------------------------------------------------------------- Statistik

    private fun netName(): String {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Seluler"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Kabel"
            else -> "Online"
        }
    }

    private fun measurePing() {
        Thread {
            var ms = -1
            try {
                val t0 = System.nanoTime()
                val c = URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection
                c.connectTimeout = 2500
                c.readTimeout = 2500
                c.useCaches = false
                val code = c.responseCode
                c.disconnect()
                if (code > 0) ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
            } catch (e: Exception) {
                ms = -1
            }
            pingMs = ms
        }.start()
    }

    private fun updateStats() {
        try {
            tvPing?.text = if (pingMs >= 0) "$pingMs ms" else "--"
            tvNet?.text = netName()
            tvTemp?.text = "%.1f°C".format(Sys.batteryTemp(this))

            val dsp = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            tvHz?.text = dsp.refreshRate.toInt().toString() + " Hz"

            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            tvInfo?.text = "RAM %.1f GB  Baterai %d%%".format(mi.availMem / 1073741824.0, bat)

            tvTorch?.text = if (Sys.torch(this)) "NYALA" else "MATI"
        } catch (e: Exception) {
            // abaikan satu putaran
        }
    }

    // ---------------------------------------------------------------- HUD monitor (fitur terkunci)

    private var hudBox: LinearLayout? = null
    private var hudLp: WindowManager.LayoutParams? = null
    private var hudL1: TextView? = null
    private var hudL2: TextView? = null
    private var hudTicks = 0
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L

    private val hudTick = object : Runnable {
        override fun run() {
            if (hudBox == null) return
            if (hudTicks % 5 == 0) measurePing()
            hudTicks++
            updateHud()
            ui.postDelayed(this, 1000)
        }
    }

    /** Menampilkan atau menyembunyikan HUD sesuai pengaturan dan status unlock. */
    fun refreshHud() {
        ui.post {
            val want = prefs.getBoolean("hud", false) && Shop.has(this, "hud") && Settings.canDrawOverlays(this)
            if (want && hudBox == null) showHud() else if (!want && hudBox != null) hideHud()
        }
    }

    private fun showHud() {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("hx", dp(8))
        p.y = prefs.getInt("hy", dp(40))

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = round(Color.argb(0xB4, 0, 0, 0), dp(10))
        box.setPadding(dp(8), dp(5), dp(8), dp(5))
        val l1 = label("PING --", 10f, Color.WHITE, true)
        val l2 = label("", 10f, Color.argb(0xDD, 255, 255, 255), false)
        l1.typeface = Typeface.MONOSPACE
        l2.typeface = Typeface.MONOSPACE
        l1.includeFontPadding = false
        l2.includeFontPadding = false
        box.addView(l1)
        box.addView(l2)

        hudBox = box
        hudLp = p
        hudL1 = l1
        hudL2 = l2
        drag(box, p, box, false) {}
        lastT = 0L
        hudTicks = 0
        wm.addView(box, p)
        ui.post(hudTick)
    }

    private fun hideHud() {
        ui.removeCallbacks(hudTick)
        hudBox?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }
        hudBox = null
        hudLp = null
        hudL1 = null
        hudL2 = null
    }

    private fun saveHudPos() {
        hudLp?.let { prefs.edit().putInt("hx", it.x).putInt("hy", it.y).apply() }
    }

    private fun spd(b: Long): String =
        if (b >= 1048576) "%.1fMB/s".format(b / 1048576.0) else "%dKB/s".format(b / 1024)

    private fun updateHud() {
        try {
            val now = System.currentTimeMillis()
            val rx = android.net.TrafficStats.getTotalRxBytes()
            val tx = android.net.TrafficStats.getTotalTxBytes()
            var down = 0L
            var up = 0L
            if (lastT > 0 && rx >= 0 && tx >= 0) {
                val dt = maxOf(1L, now - lastT)
                down = maxOf(0L, (rx - lastRx) * 1000 / dt)
                up = maxOf(0L, (tx - lastTx) * 1000 / dt)
            }
            lastRx = rx
            lastTx = tx
            lastT = now
            val ping = if (pingMs >= 0) "$pingMs ms" else "--"
            hudL1?.text = "PING $ping  \u2193${spd(down)} \u2191${spd(up)}"

            val ram = Sys.ramMb(this)
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            hudL2?.text = "RAM %.1fG  %.0f\u00B0C  %dHz  %d%%".format(
                ram.first / 1024.0, Sys.batteryTemp(this), Sys.curHz(this).toInt(), bat
            )
        } catch (e: Exception) {
            // abaikan satu putaran
        }
    }

    private fun lockToast(name: String) =
        toast("Terkunci: $name. Buka lewat kode atau Toko di aplikasi")

    /** Boost 1 ketuk: bersihkan, Mode Game, dan opsi Pro yang sudah terbuka. */
    private fun boostNow() {
        prefs.edit().putBoolean("game", true).apply()
        if (Shop.has(this, "hz")) Sys.setHz(this, true)
        if (Shop.has(this, "anim")) Sys.setAnim(this, true)
        refresh()
        cleanNow()
    }

    // ---------------------------------------------------------------- Pemilih aplikasi

    private fun setFocusableFor(v: View?, p: WindowManager.LayoutParams?, on: Boolean) {
        if (v == null || p == null) return
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val flags = if (on) p.flags and nf.inv() else p.flags or nf
        if (flags != p.flags) {
            p.flags = flags
            try {
                wm.updateViewLayout(v, p)
            } catch (e: Exception) {
                // jendela sudah dilepas
            }
        }
    }

    private fun popupParams(w: Int, h: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.CENTER
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        return p
    }

    private fun popupBox(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = round(withA(pal.surface, 0xF8), dp(18)).apply { setStroke(dp(1), withA(pal.text, 0x33)) }
        box.setPadding(dp(12), dp(10), dp(12), dp(10))
        return box
    }

    private fun popupHead(title: String): View {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(
            label(title, 15f, pal.text, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(pal.text)
        x.setPadding(dp(6), dp(6), dp(6), dp(6))
        x.setOnClickListener { closePicker() }
        head.addView(x, LinearLayout.LayoutParams(dp(34), dp(34)))
        return head
    }

    private fun showPopup(box: View, p: WindowManager.LayoutParams) {
        pickerBox = box
        pickerLp = p
        wm.addView(box, p)
        box.alpha = 0f
        box.animate().alpha(1f).setDuration(200).start()
    }

    /**
     * Daftar semua aplikasi terpasang.
     * launch = true: ketuk untuk membuka melayang, tekan lama untuk menaruh di panel.
     * launch = false: ketuk untuk memilih atau melepas slot panel.
     */
    private fun showPicker(launch: Boolean) {
        closePicker()
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = pm.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        val m = resources.displayMetrics
        val w = minOf(dp(340), m.widthPixels - dp(24))
        val h = (m.heightPixels * 0.7f).toInt()
        val p = popupParams(w, h)

        val box = popupBox()
        box.addView(popupHead(if (launch) "Semua aplikasi (melayang)" else "Pilih aplikasi untuk panel"))

        val search = EditText(this)
        search.hint = "Cari aplikasi"
        search.setSingleLine(true)
        search.setTextColor(pal.text)
        search.setHintTextColor(withA(pal.text, 0x77))
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        search.background = round(withA(pal.text, 0x14), dp(10))
        search.setPadding(dp(12), dp(8), dp(12), dp(8))
        search.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) setFocusableFor(pickerBox, pickerLp, true)
            false
        }
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sp.topMargin = dp(8)
        sp.bottomMargin = dp(4)
        box.addView(search, sp)

        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        val selected = loadApps().map { it.pkg }.toMutableSet()
        val rows = mutableListOf<Pair<String, View>>()

        all.forEach { (name, pkg) ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(8), dp(4), dp(8))

            val iv = ImageView(this)
            try {
                iv.setImageDrawable(pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                // tanpa ikon
            }
            row.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
            row.addView(
                label(name, 14f, pal.text, false).apply { setPadding(dp(12), 0, dp(8), 0); maxLines = 1 },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            val state = label(if (pkg in selected) "Di panel" else "", 12f, pal.accent, true)
            row.addView(state)

            fun toggleSlot() {
                val list = loadApps()
                if (pkg in selected) {
                    selected.remove(pkg)
                    saveApps(list.filter { it.pkg != pkg })
                    state.text = ""
                } else if (list.size >= 8) {
                    toast("Panel hanya memuat 8 aplikasi")
                } else {
                    selected.add(pkg)
                    list.add(AppItem(System.currentTimeMillis(), name, pkg))
                    saveApps(list)
                    state.text = "Di panel"
                    if (launch) toast("$name ditaruh di panel")
                }
            }

            if (launch) {
                row.setOnClickListener {
                    closePicker()
                    launchApp(name, pkg)
                }
                row.setOnLongClickListener {
                    toggleSlot()
                    true
                }
            } else {
                row.setOnClickListener { toggleSlot() }
            }
            rows.add(Pair(name, row))
            listBox.addView(row)
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val q = (s?.toString() ?: "").trim().lowercase()
                rows.forEach { (name, v) ->
                    v.visibility = if (q.isEmpty() || name.lowercase().contains(q)) View.VISIBLE else View.GONE
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        if (launch) {
            val hint = label("Ketuk untuk membuka melayang. Tekan lama untuk menaruh di panel.", 11f, withA(pal.text, 0x99), false)
            hint.setPadding(dp(4), dp(4), dp(4), dp(4))
            box.addView(hint)
        }

        val scroll = ScrollView(this)
        scroll.addView(listBox)
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        showPopup(box, p)
    }

    // ---------------------------------------------------------------- Alat cepat

    private fun sizeName(): String = when (prefs.getString("fsize", "m")) {
        "s" -> "Kecil"
        "l" -> "Besar"
        else -> "Sedang"
    }

    private fun showTools() {
        closePicker()
        val m = resources.displayMetrics
        val w = minOf(dp(320), m.widthPixels - dp(24))
        val p = popupParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)

        val box = popupBox()
        box.addView(popupHead("Alat cepat"))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(0, dp(6), 0, 0)

        fun tbtn(text: String, wdp: Int, onClick: () -> Unit): View {
            val b = button(text, true, onClick)
            b.layoutParams = LinearLayout.LayoutParams(dp(wdp), dp(34)).apply { leftMargin = dp(6) }
            return b
        }

        fun row(title: String, value: TextView?, vararg items: View) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(5), 0, dp(5))
            r.addView(
                label(title, 14f, pal.text, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            if (value != null) r.addView(value)
            items.forEach { r.addView(it) }
            body.addView(r)
        }

        fun valueText(s: String): TextView = label(s, 13f, withA(pal.text, 0xB0), false)

        // Senter
        val tv = valueText(if (Sys.torch(this)) "Nyala" else "Mati")
        row("Senter", tv, tbtn("Ubah", 64) {
            toggleTorch()
            tv.text = if (Sys.torch(this)) "Nyala" else "Mati"
        })

        // Kecerahan
        val bv = valueText(Sys.brightness(this).let { if (it >= 0) "$it%" else "--" })
        fun stepBrightness(d: Int) {
            if (!Sys.canWriteSettings(this)) {
                askWriteSettings()
                return
            }
            val cur = Sys.brightness(this).let { if (it < 0) 50 else it }
            Sys.setBrightness(this, cur + d)
            bv.text = Sys.brightness(this).let { if (it >= 0) "$it%" else "--" }
        }
        row("Kecerahan", bv, tbtn("-", 40) { stepBrightness(-10) }, tbtn("+", 40) { stepBrightness(10) })

        // Volume media
        val vv = valueText("${Sys.volume(this)}%")
        fun stepVolume(d: Int) {
            Sys.setVolume(this, Sys.volume(this) + d)
            vv.text = "${Sys.volume(this)}%"
        }
        row("Volume media", vv, tbtn("-", 40) { stepVolume(-10) }, tbtn("+", 40) { stepVolume(10) })

        // Putar otomatis
        val rv = valueText(if (Sys.autoRotate(this)) "Nyala" else "Mati")
        row("Putar otomatis", rv, tbtn("Ubah", 64) {
            if (!Sys.canWriteSettings(this)) {
                askWriteSettings()
            } else {
                Sys.setAutoRotate(this, !Sys.autoRotate(this))
                rv.text = if (Sys.autoRotate(this)) "Nyala" else "Mati"
            }
        })

        // Panel sistem
        row("Panel cepat", null,
            tbtn("Internet", 70) { Sys.openPanel(this, Settings.Panel.ACTION_INTERNET_CONNECTIVITY); closePicker() },
            tbtn("Suara", 56) { Sys.openPanel(this, Settings.Panel.ACTION_VOLUME); closePicker() })

        // Ukuran jendela melayang
        val sv = valueText(sizeName())
        fun setSize(code: String) {
            prefs.edit().putString("fsize", code).apply()
            sv.text = sizeName()
        }
        row("Ukuran jendela", sv, tbtn("K", 36) { setSize("s") }, tbtn("S", 36) { setSize("m") }, tbtn("B", 36) { setSize("l") })

        // Fitur Pro (terkunci sampai kode dimasukkan)
        row("Boost 1 ketuk", null, tbtn("Boost", 64) {
            if (!Shop.has(this, "boost")) lockToast("Game Booster Pro") else { closePicker(); boostNow() }
        })

        val hv = valueText(if (prefs.getBoolean("hud", false) && Shop.has(this, "hud")) "Nyala" else "Mati")
        row("HUD monitor", hv, tbtn("Ubah", 64) {
            if (!Shop.has(this, "hud")) {
                lockToast("HUD monitor")
            } else {
                prefs.edit().putBoolean("hud", !prefs.getBoolean("hud", false)).apply()
                refreshHud()
                hv.text = if (prefs.getBoolean("hud", false)) "Nyala" else "Mati"
            }
        })

        val av = valueText(if (Sys.animFast(this)) "Cepat" else "Normal")
        row("Animasi cepat", av, tbtn("Ubah", 64) {
            if (!Shop.has(this, "anim")) {
                lockToast("Animasi cepat")
            } else if (Sys.setAnim(this, !Sys.animFast(this))) {
                av.text = if (Sys.animFast(this)) "Cepat" else "Normal"
            } else {
                toast("Butuh izin lewat Shizuku atau ADB (lihat Jendela asli)")
            }
        })

        val zv = valueText(if (Sys.hzForced(this)) "Tinggi" else "Auto")
        row("Hz tinggi", zv, tbtn("Ubah", 64) {
            if (!Shop.has(this, "hz")) {
                lockToast("Paksa Hz tinggi")
            } else if (!Sys.canWriteSettings(this)) {
                askWriteSettings()
            } else if (Sys.setHz(this, !Sys.hzForced(this))) {
                zv.text = if (Sys.hzForced(this)) "Tinggi" else "Auto"
            } else {
                toast("Perangkat ini tidak mendukung")
            }
        })

        // Jendela asli untuk semua aplikasi
        val fv = valueText(
            if (Sys.freeformOn(this) && Sys.forcedResize(this)) "Aktif"
            else if (Sys.freeformOn(this)) "Sebagian" else "Mati"
        )
        row("Jendela asli", fv, tbtn("Nyalakan", 74) {
            if (!Shop.has(this, "float")) {
                lockToast("Jendela melayang semua aplikasi")
                return@tbtn
            }
            if (Sys.setFloatAll(this, true)) {
                fv.text = "Aktif"
                toast("Jendela melayang aktif untuk semua aplikasi")
            } else when (Sys.shizukuState()) {
                "ready" -> {
                    toast("Meminta izin lewat Shizuku")
                    Thread {
                        val ok = Sys.shizukuGrant(this) && Sys.setFloatAll(this, true)
                        ui.post {
                            if (ok) fv.text = "Aktif"
                            toast(if (ok) "Jendela melayang aktif untuk semua aplikasi" else "Gagal lewat Shizuku, coba cara ADB")
                        }
                    }.start()
                }
                "ask" -> {
                    Sys.shizukuAsk(21)
                    toast("Izinkan Fluu GX di popup Shizuku, lalu ketuk Nyalakan lagi")
                }
                else -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Fluu GX", Sys.adbCommand(this)))
                    toast("Shizuku belum jalan. Jalankan Shizuku, atau tempel perintah ADB yang sudah disalin")
                }
            }
        })

        // Tangkapan layar (lewat Shizuku)
        row("Tangkapan layar", null, tbtn("Ambil", 64) {
            if (Sys.shizukuState() != "ready") {
                toast("Butuh Shizuku yang sedang berjalan")
            } else {
                closePicker()
                setOpen(false)
                ui.postDelayed({
                    Thread {
                        val ok = Sys.screenshot()
                        ui.post { toast(if (ok) "Tersimpan di Pictures/Screenshots" else "Gagal mengambil tangkapan layar") }
                    }.start()
                }, 700)
            }
        })

        // Jendela asli yang sedang terbuka
        if (ctls.isNotEmpty()) {
            row("Jendela melayang", valueText("${ctls.size} terbuka"), tbtn("Tutup", 64) {
                closeAllCtl(true)
                closePicker()
            })
        }

        // Tutup jendela web melayang
        if (webBox != null) {
            row("Jendela web", null, tbtn("Tutup", 64) { closeWeb(); closePicker() })
        }

        p.height = minOf(dp(46) * body.childCount + dp(80), (m.heightPixels * 0.8f).toInt())
        val sv2 = ScrollView(this)
        sv2.addView(body)
        box.addView(sv2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        showPopup(box, p)
    }

    private fun closePicker() {
        pickerBox?.let {
            try {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0)
            } catch (e: Exception) {
                // abaikan
            }
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }
        pickerBox = null
        pickerLp = null
    }

    // ---------------------------------------------------------------- Kontrol jendela asli

    private val ctls = mutableMapOf<String, FloatCtl>()
    private val shellPool = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var watching = false

    /** Memeriksa tiap beberapa detik; kontrol dilepas bila jendelanya sudah tertutup. */
    private val watchTick = object : Runnable {
        override fun run() {
            if (ctls.isEmpty()) {
                watching = false
                return
            }
            val pkgs = ctls.keys.toList()
            shellPool.execute {
                pkgs.forEach { pkg ->
                    if (Sys.findTaskId(pkg) == -1) ui.post { closeCtl(pkg, false) }
                }
            }
            ui.postDelayed(this, 4000)
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): android.graphics.Point {
        val dm = android.util.DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return android.graphics.Point(dm.widthPixels, dm.heightPixels)
    }

    /** Posisi awal jendela sesuai pilihan ukuran (Kecil, Sedang, Besar). */
    private fun floatBounds(): Rect {
        val s = screenSize()
        val f = when (prefs.getString("fsize", "m")) {
            "s" -> 0.55f
            "l" -> 0.9f
            else -> 0.72f
        }
        val w = maxOf((s.x * f).toInt(), dp(220))
        val h = (s.y * (f - 0.05f)).toInt()
        val l = (s.x - w) / 2
        val t = maxOf(dp(56), (s.y - h) / 4)
        return Rect(l, t, l + w, t + h)
    }

    private fun ctlParams(w: Int, h: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    private fun ctlIcon(res: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(pal.text)
        v.setPadding(dp(6), dp(6), dp(6), dp(6))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun showCtl(pkg: String, name: String, taskId: Int, b: Rect) {
        closeCtl(pkg, false)
        val c = FloatCtl(pkg, name, taskId, b)
        ctls[pkg] = c
        c.attach()
        if (!watching) {
            watching = true
            ui.postDelayed(watchTick, 4000)
        }
    }

    private fun closeCtl(pkg: String, stop: Boolean) {
        val c = ctls.remove(pkg) ?: return
        c.detach()
        if (stop) shellPool.execute { Sys.forceStop(pkg) }
    }

    private fun closeAllCtl(stop: Boolean) {
        ctls.keys.toList().forEach { closeCtl(it, stop) }
    }

    /**
     * Bilah kontrol di atas dan bawah sebuah jendela freeform: geser, ubah ukuran,
     * tempel setengah layar, layar penuh, dan tutup. Digambar dengan sudut membulat
     * sehingga jendela terlihat rapi seperti kartu.
     */
    private inner class FloatCtl(val pkg: String, val name: String, val taskId: Int, var b: Rect) {
        private val barH = dp(30)
        private val gripH = dp(22)
        private val minW = dp(220)
        private val minH = dp(260)
        private val top = LinearLayout(this@OverlayService)
        private val bottom = FrameLayout(this@OverlayService)
        private val topLp = ctlParams(b.width(), barH)
        private val botLp = ctlParams(b.width(), gripH)
        private var full = false
        private var saved = Rect(b)
        private var snap = 0

        @Volatile
        private var pending: Rect? = null
        private var busy = false

        init {
            val r = dp(14).toFloat()
            top.orientation = LinearLayout.HORIZONTAL
            top.gravity = Gravity.CENTER_VERTICAL
            top.setPadding(dp(10), 0, dp(4), 0)
            top.background = GradientDrawable().apply {
                setColor(withA(pal.surface, 0xF5))
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), withA(pal.accent, 0x66))
            }

            val title = label(name, 12f, pal.text, true)
            title.maxLines = 1
            title.ellipsize = android.text.TextUtils.TruncateAt.END
            title.gravity = Gravity.CENTER_VERTICAL
            top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

            fun add(res: Int, onClick: () -> Unit) {
                top.addView(ctlIcon(res, onClick), LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.MATCH_PARENT))
            }
            add(R.drawable.ic_snap) { snapNext() }
            add(R.drawable.ic_minus) { scale(0.85f) }
            add(R.drawable.ic_plus) { scale(1.18f) }
            add(R.drawable.ic_expand) { toggleFull() }
            add(R.drawable.ic_close) { closeCtl(pkg, true) }

            // geser jendela lewat judul
            var sx = 0f
            var sy = 0f
            var ol = 0
            var ot = 0
            title.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ol = b.left
                        ot = b.top
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val s = screenSize()
                        val w = b.width()
                        val h = b.height()
                        val nl = (ol + (e.rawX - sx)).toInt().coerceIn(0, maxOf(0, s.x - w))
                        val nt = (ot + (e.rawY - sy)).toInt().coerceIn(barH, maxOf(barH, s.y - h - gripH))
                        b = Rect(nl, nt, nl + w, nt + h)
                        full = false
                        place()
                        push()
                    }
                    MotionEvent.ACTION_UP -> push()
                }
                true
            }

            // pegangan bawah untuk mengubah ukuran
            bottom.background = GradientDrawable().apply {
                setColor(withA(pal.surface, 0xF5))
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
                setStroke(dp(1), withA(pal.accent, 0x66))
            }
            val pill = View(this@OverlayService)
            pill.background = round(withA(pal.text, 0x77), dp(2))
            val pl = FrameLayout.LayoutParams(dp(48), dp(4))
            pl.gravity = Gravity.CENTER
            bottom.addView(pill, pl)

            var rx = 0f
            var ry = 0f
            var ow = 0
            var oh = 0
            bottom.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        rx = e.rawX
                        ry = e.rawY
                        ow = b.width()
                        oh = b.height()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val s = screenSize()
                        val nw = (ow + (e.rawX - rx)).toInt().coerceIn(minW, maxOf(minW, s.x - b.left))
                        val nh = (oh + (e.rawY - ry)).toInt().coerceIn(minH, maxOf(minH, s.y - b.top - gripH))
                        b = Rect(b.left, b.top, b.left + nw, b.top + nh)
                        full = false
                        place()
                        push()
                    }
                    MotionEvent.ACTION_UP -> push()
                }
                true
            }
        }

        fun attach() {
            topLp.x = b.left
            topLp.y = b.top - barH
            botLp.x = b.left
            botLp.y = b.bottom
            wm.addView(top, topLp)
            wm.addView(bottom, botLp)
        }

        fun detach() {
            try {
                wm.removeView(top)
            } catch (e: Exception) {
                // sudah dilepas
            }
            try {
                wm.removeView(bottom)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }

        private fun place() {
            topLp.x = b.left
            topLp.y = b.top - barH
            topLp.width = b.width()
            botLp.x = b.left
            botLp.y = b.bottom
            botLp.width = b.width()
            try {
                wm.updateViewLayout(top, topLp)
                wm.updateViewLayout(bottom, botLp)
            } catch (e: Exception) {
                // jendela kontrol sudah dilepas
            }
        }

        /** Kirim posisi terbaru ke sistem. Perubahan beruntun digabung agar tidak menumpuk. */
        private fun push() {
            pending = Rect(b)
            if (busy) return
            busy = true
            shellPool.execute {
                while (true) {
                    val r = pending ?: break
                    pending = null
                    Sys.resizeTask(taskId, r)
                }
                ui.post {
                    busy = false
                    if (pending != null) push()
                }
            }
        }

        private fun commit(r: Rect) {
            b = r
            place()
            push()
        }

        private fun scale(f: Float) {
            val s = screenSize()
            val nw = (b.width() * f).toInt().coerceIn(minW, s.x)
            val nh = (b.height() * f).toInt().coerceIn(minH, maxOf(minH, s.y - barH - gripH))
            val nl = (b.centerX() - nw / 2).coerceIn(0, maxOf(0, s.x - nw))
            val nt = (b.centerY() - nh / 2).coerceIn(barH, maxOf(barH, s.y - nh - gripH))
            full = false
            commit(Rect(nl, nt, nl + nw, nt + nh))
        }

        private fun toggleFull() {
            val s = screenSize()
            if (!full) {
                saved = Rect(b)
                full = true
                commit(Rect(0, barH, s.x, s.y - gripH))
            } else {
                full = false
                commit(Rect(saved))
            }
        }

        /** Tempel bergantian: kiri, kanan, atas, bawah. */
        private fun snapNext() {
            val s = screenSize()
            val y0 = barH
            val y1 = s.y - gripH
            val mid = (y0 + y1) / 2
            val r = when (snap % 4) {
                0 -> Rect(0, y0, s.x / 2, y1)
                1 -> Rect(s.x / 2, y0, s.x, y1)
                2 -> Rect(0, y0, s.x, mid - gripH)
                else -> Rect(0, mid + barH, s.x, y1)
            }
            snap++
            full = false
            commit(r)
        }
    }

    // ---------------------------------------------------------------- Jendela web melayang

    private fun showWeb(title: String, app: WebApp) {
        closeWeb()
        val m = resources.displayMetrics
        val w = minOf(dp(340), m.widthPixels - dp(16))
        val h = minOf(dp(500), (m.heightPixels * 0.72f).toInt())

        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (m.widthPixels - w) / 2
        p.y = dp(48)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = round(pal.surface, dp(16)).apply { setStroke(dp(1), withA(pal.accent, 0x99)) }
        box.outlineProvider = ViewOutlineProvider.BACKGROUND
        box.clipToOutline = true

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(4), dp(4), dp(4))
        bar.setBackgroundColor(withA(pal.accent, 0x30))
        bar.addView(
            label(title, 14f, pal.text, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        bar.addView(button("Lepas", false) { releaseWebFocus() }, LinearLayout.LayoutParams(dp(60), dp(32)))
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(pal.text)
        x.setPadding(dp(8), dp(8), dp(8), dp(8))
        x.setOnClickListener { closeWeb() }
        bar.addView(x, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(bar)

        val wv = WebView(applicationContext)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        if (app.desktop) wv.settings.userAgentString = DESKTOP_UA
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.webViewClient = WebViewClient()
        wv.setBackgroundColor(pal.surface)
        wv.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) setWebFocusable(true)
            false
        }
        wv.loadUrl(app.url)
        box.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        drag(bar, p, box, false) {}

        webBox = box
        webLp = p
        webView = wv
        wm.addView(box, p)
        box.alpha = 0f
        box.scaleX = .9f
        box.scaleY = .9f
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    /** Jendela web perlu fokus agar keyboard muncul; setelah itu fokus dikembalikan ke game. */
    private fun setWebFocusable(on: Boolean) {
        val p = webLp ?: return
        val b = webBox ?: return
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val flags = if (on) p.flags and nf.inv() else p.flags or nf
        if (flags != p.flags) {
            p.flags = flags
            try {
                wm.updateViewLayout(b, p)
            } catch (e: Exception) {
                // jendela sudah dilepas
            }
        }
    }

    private fun releaseWebFocus() {
        setWebFocusable(false)
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(webBox?.windowToken, 0)
    }

    private fun closeWeb() {
        webView?.let {
            it.stopLoading()
            it.destroy()
        }
        webView = null
        webBox?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }
        webBox = null
        webLp = null
    }
}
